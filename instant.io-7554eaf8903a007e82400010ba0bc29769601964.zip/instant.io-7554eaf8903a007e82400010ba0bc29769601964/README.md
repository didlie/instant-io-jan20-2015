# instant.io

### Secure, anonymous, streaming file transfer

Download/upload files using the [WebTorrent](http://webtorrent.io) protocol (BitTorrent over WebRTC). This is a beta.

Run <code>localStorage.debug = '*'</code>in the console and refresh to get detailed log output.

## license

MIT. Copyright (c) [Feross Aboukhadijeh](http://feross.org).

